
--drop table clientes2
--criando tabela clientes2 atraves de select
select * into clientes2 from clientes
--deletando registros
delete from clientes2

